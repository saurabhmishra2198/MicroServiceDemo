﻿using ProductAPI.DTO.DTOModel;

namespace ProductAPI.Services
{
    public interface IProductServices
    {
        Task<ResponseEntity> GetAllProduct();
    }
}
