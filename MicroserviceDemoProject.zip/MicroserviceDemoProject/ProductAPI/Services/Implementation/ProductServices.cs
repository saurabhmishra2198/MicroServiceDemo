﻿using ProductAPI.DTO.DTOModel;
using ProductAPI.Repository;

namespace ProductAPI.Services.Implementation
{
    public class ProductServices : IProductServices
    {
        private readonly IProductRepository _repository;
        public ProductServices(IProductRepository repository)
        {
            _repository = repository;
        }
        public async Task<ResponseEntity> GetAllProduct()
        {
            return await _repository.GetAllProduct();
        }
    }
}
