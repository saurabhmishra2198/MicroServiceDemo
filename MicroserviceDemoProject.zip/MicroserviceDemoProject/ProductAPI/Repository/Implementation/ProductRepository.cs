﻿using ProductAPI.Data;
using ProductAPI.DTO.DTOModel;

namespace ProductAPI.Repository.Implementation
{
    public class ProductRepository : IProductRepository
    {
        private readonly ProductDbContext _dbContext;

        public ProductRepository(ProductDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<ResponseEntity> GetAllProduct()
        {
            ResponseEntity response = new ResponseEntity();
            try
            {
                List<ProductModel> products = new List<ProductModel>()
                {
                   new ProductModel { Id = Guid.NewGuid(), ProductName = "Mobile", Description = "This is mobile", Price = 300.50m },
                    new ProductModel { Id = Guid.NewGuid(), ProductName = "PC", Description = "This is PC", Price = 400.50m },
                };
                if(products.Count > 0 )
                {
                    response.Status = 1;
                    response.Message = "Product record found.";
                    response.Data = products;
                    response.TotalReponse = products.Count;
                }
                else
                {
                    response.Status = 0;
                    response.ErrorMessage = "No Record found";
                }
            }
            catch (Exception ex)
            {
                response.Status = 0;
                response.ErrorMessage = "Error: " + ex.Message;
            }
            return response;
        }
    }
}
