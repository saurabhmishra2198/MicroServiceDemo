﻿using ProductAPI.DTO.DTOModel;

namespace ProductAPI.Repository
{
    public interface IProductRepository
    {
        Task<ResponseEntity> GetAllProduct();
    }
}
