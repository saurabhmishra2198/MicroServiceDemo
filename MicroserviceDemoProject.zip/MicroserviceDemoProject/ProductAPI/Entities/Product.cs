﻿using System.ComponentModel.DataAnnotations;

namespace ProductAPI.Entities
{
    public class Product
    {
        [Key]
        public Guid Id { get; set; }
        [Required]
        public string ProductName { get; set; } = string.Empty;
        [Required]
        [StringLength(100,ErrorMessage = "Please input 100 characters")]
        public string Description { get; set; } = string.Empty;
        [Required]
        public decimal Price { get; set; }
    }
}
