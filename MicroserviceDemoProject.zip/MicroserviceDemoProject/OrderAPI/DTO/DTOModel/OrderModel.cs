﻿namespace OrderAPI.DTO.DTOModel
{
    public class OrderModel
    {
        public Guid Id { get; set; }
        public int Quantity { get; set; }
        public decimal TotalPrice { get; set; }
        public string ProductName { get; set; } = string.Empty;
    }
}
