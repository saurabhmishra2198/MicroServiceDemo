﻿namespace OrderAPI.DTO.DTOModel
{
    public class ResponseEntity
    {
        public int Status { get; set; }
        public string Message { get; set; } = string.Empty;
        public string ErrorMessage { get; set; } = string.Empty;
        public object Data { get; set; } = string.Empty;
        public int TotalReponse { get; set; }
    }
}
