﻿using System.ComponentModel.DataAnnotations;

namespace OrderAPI.Entities
{
    public class Order
    {
        [Key]
        public Guid Id { get; set; }
        [Required]
        public int Quantity { get; set; }
        [Required]
        public decimal TotalPrice { get; set; }
        [Required]
        public string ProductName { get; set; } = string.Empty;
    }
}
