﻿using OrderAPI.DTO.DTOModel;
using OrderAPI.Repository;

namespace OrderAPI.Services.Implementation
{
    public class OrderServices : IOrderServices
    {
        private readonly IOrderRepository _orderRepository;

        public OrderServices(IOrderRepository orderRepository)
        {
            _orderRepository = orderRepository;
        }
        public async Task<ResponseEntity> GetAllOrders()
        {
            return await _orderRepository.GetAllOrders();
        }
    }
}
