﻿using OrderAPI.DTO.DTOModel;

namespace OrderAPI.Services
{
    public interface IOrderServices
    {
        Task<ResponseEntity> GetAllOrders();
    }
}
