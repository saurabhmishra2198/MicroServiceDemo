﻿using OrderAPI.Data;
using OrderAPI.DTO.DTOModel;

namespace OrderAPI.Repository.Implementation
{
    public class OrderRepository : IOrderRepository
    {
        private readonly OrderDbContext _context;

        public OrderRepository(OrderDbContext context)
        {
            _context = context;
        }

        public async Task<ResponseEntity> GetAllOrders()
        {
            ResponseEntity response = new ResponseEntity();
            try
            {
                List<OrderModel> orders = new List<OrderModel>()
                {
                    new OrderModel {Id = Guid.NewGuid(), ProductName = "Mobile", Quantity = 1, TotalPrice = 100},
                    new OrderModel {Id = Guid.NewGuid(), ProductName = "PC", Quantity = 2, TotalPrice = 1200},
                };
                if(orders.Count > 0 )
                {
                    response.Status = 1;
                    response.Data = orders;
                    response.Message = "Record found successfully.";
                    response.TotalReponse = orders.Count;
                }
                else
                {
                    response.Status = 0;
                    response.ErrorMessage = "Record not found.";
                }
            }
            catch (Exception ex)
            {
                response.Status = 0;
                response.ErrorMessage = "Error: "+ ex.Message;
            }
            return response;
        }
    }
}
