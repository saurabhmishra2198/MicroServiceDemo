﻿using OrderAPI.DTO.DTOModel;

namespace OrderAPI.Repository
{
    public interface IOrderRepository
    {
        Task<ResponseEntity> GetAllOrders();
    }
}
