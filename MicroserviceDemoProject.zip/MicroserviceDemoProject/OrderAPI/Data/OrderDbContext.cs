﻿using Microsoft.EntityFrameworkCore;
using OrderAPI.Entities;

namespace OrderAPI.Data
{
    public class OrderDbContext : DbContext
    {
        public OrderDbContext(DbContextOptions<OrderDbContext> options)
        {
            
        }
        public DbSet<Order> Orders { get; set; }
    }
}
